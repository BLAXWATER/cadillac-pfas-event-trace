The data in these files is obtained from Wellogic, the Michigan Department of Environmental Quality Statewide Ground Water Database.  Wellogic contains over 500,000 water well records found within the State of Michigan, and although it represents the best available data, it cannot be considered a complete database of all the well records in existence, nor can the information be considered completely accurate.  

Beginning January 1, 2000 virtually 100% of new wells constructed are accounted for in Wellogic, however for wells older than 2000 the rate of inclusion varies from county to county, and may be considerably lower. 

The locational data also has varying degrees of accuracy; ranging from precise GPS point collection to address geocoding, but there may also be erroneous locations regardless of collection method that have not been corrected as of yet.  Refer to the metadata provided on X Y attributes to determine each individual record�s potential locational accuracy.

------------------------------------------------------------------------------------------

Field Definitions:

� WELLID : Wellogic ID number (unique identifying number, first 2 digits represent county number)

� PERMIT_NUM : Well permit number as assigned by local health department

� WELL_TYPE : Type of well

	OTH	= Other
	HEATP	= Heat pump
	HOSHLD	= Household
	INDUS	= Industrial
	IRRI	= Irrigation
	TESTW	= Test well
	TY1PU	= Type I public
	TY2PU	= Type II public
	TY3PU	= Type III public

� TYPE_OTHER : Type of well if WELL_TYPE is 'OTH'

� WEL_STATUS : Status of well

	OTH	= Other
	ACT	= Active
	INACT	= Inactive
	PLU	= Plugged/Abandoned

� STATUS_OTH : Status of well if WEL_STATUS is 'OTH' 

� WSSN : Water Supply Serial Number, only if public well

� WELL_NUM : Individual well number/name, only if public well

� DRILLER_ID : Water Well Drilling Contractor Registration Number as assigned by State of Michigan 

� DRILL_METH : Method used to drill the well borehole

	OTH	= Other	
	AUGBOR	= Auger/Bored	
	CABTOO	= Cable Tool	
	CASHAM	= Casing Hammer	
	DRIVEN	= Driven Hand	
	HOLROD	= Hollow Rod	
	JETTIN	= Jetted

� METH_OTHER : Method used to drill if DRILL_METH is 'OTH'

� CASE_TYPE : Well casing type

        OTH 	= Other
        UNK 	= Unknown
        PVCPLA 	= PVC Plastic
        STEBLA 	= Steel-black
	STEGAL 	= Steel-Galvanized

� CASE_OTHER : Well casing type is CASE_TYPE is 'OTH'

� CASE_DIA : Well Casing Diameter (in inches)

� CASE_DEPTH : Depth of Casing (in feet) 

� SCREEN_FRM : Depth of top of screen (in feet)

� SCREEN_TO : Depth of bottom of screen (in feet)

� SWL : Depth of Static Water Level (in feet)

� FLOWING : Naturally flowing well (Y or N)

� AQ_TYPE : Aquifer type

	DRIFT   = Well draws water from the glacial drift
	ROCK    = Well draws water from the bedrock
	DRYHOL  = Dry hole, well did not produce water
	UNK     = Unknown

� TEST_DEPTH : Depth of drawdown when the well was developed (in feet)

� TEST_HOURS : Duration of pumping when the well was developed (in hours)

� TEST_RATE : Rate of water flow when the well was developed (in Gallons per Minute)

� TEST_METHD : Method used to develop the well

	UNK     = Unknown
	OTH     = Other
	AIR     = Air
	BAIL    = Bailer
	PLUGR   = Plunger
	TSTPUM  = Test Pump 

� TEST_OTHER : Method used to develop the well if TEST_METHD is 'OTH'

� GROUT : Whether the well was grouted or not

� PMP_CPCITY : Capacity of the pump installed in the well (in Gallons per minute)

� METHD_COLL : Method of collection of the latitude/longitude coordinates

	001 = Address Matching-House Number
	002 = Address Matching-Street Centerline
	004 = Address Matching-Nearest Intersection
	012 = GPS Carrier Phase Static Relative Position Tech.
	013 = GPS Carrier Phase Kinematic Relative Position Tech.
	014 = GPS Code Measurement Differential (DGPS)
	015 = GPS Precise Positioning Service
	016 = GPS Code Meas. Std. Positioning Service  SA Off
	017 = GPS Std. Positioning Service SA On
	018 = Interpolation-Map
	019 = Interpolation-Aerial Photo
	020 = Interpolation-Satellite Photo
	025 = Classical Surveying Techniques
	027 = Section centroid
	028 = TownRange centroid
	036 = Quarter-Quarter-Quarter centroid

� ELEV_METHD : Method of collection of the elevation

	003 = GPS Code Measurement Differential (DGPS)
	005 = GPS Code Meas. Std. Positioning Svc.  SA Off
	007 = Classical Surveying Techniques
	014 = Topographic Map Interpolation
	OTH = Other
	UNK = Unknown

------------------------------------------------------------------------------------------

If you have questions concerning this data, please contact:

Anita Ladouceur, Department of Environmental Quality
phone: (517) 284-6533
email: ladouceura@michigan.gov

or

Andrew LeBaron, Department of Environmental Quality
phone: (517) 284-5563
email: lebarona@michigan.gov
